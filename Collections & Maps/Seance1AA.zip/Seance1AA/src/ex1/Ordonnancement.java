package ex1;

public class Ordonnancement {
	public static final int NIVEAU_PRIORITE_MAX=5;

	public Ordonnancement(){

	}
	public void ajouterTache (String descriptif, int priorite){

	}
	
	//renvoie la tache prioritaire
	//renvoie null si plus de tache presente
	public Tache attribuerTache(){
		
		return null;
	}
}

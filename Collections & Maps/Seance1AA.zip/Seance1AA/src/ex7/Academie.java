package ex7;

import java.util.ArrayList;

public class Academie {
	
	public Academie(ArrayList<String> v){
	}
	
	public void mettreEnAttente(String instrument, String nomEleve){
		
	} 
	
	// supprime uniquement l'�l�ve de la file d'attente et le renvoie
	// renvoie null s�il n�y a pas d��l�ve en attente pour cet instrument	
	public String attribuerPlace(String instrument){
		return null;
	} 

}

package ex7;

import java.util.ArrayList;
import java.util.Vector;

public class AcademieAvecDesistement {
	
	public AcademieAvecDesistement(ArrayList<String> v){
	}
	
	public void mettreEnAttente(String instrument, String nomEleve){
	} 
	
	public void desistement(String instrument, String eleve){
	}
	
	//supprime uniquement l'�l�ve de la file d'attente
	public String attribuerPlace(String instrument){
		return null;
	} 
	
	

}

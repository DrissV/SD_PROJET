package ex2;

public class ControleDAcces {
	
	public ControleDAcces(){
		
	}
	
	// associe le badge � un employ�
	public void donnerBadge (Badge b, Employe e){
	}
	
	// met � jour les employ�s pr�sents dans le batiment
	public void entrerBatiment (Badge b){
	}

	// met � jour les employ�s pr�sents dans le batiment
	public void sortirBatiment (Badge b){

	}
	
	// renvoie vrai si l'employ� est dans le batiment, faux sinon
	public boolean estDansBatiment (Employe e){
		return false;
	}

}

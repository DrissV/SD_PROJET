package ex2;

public class Badge {
	private int numero;

	public Badge(int numero) {
		super();
		this.numero = numero;
	}

	public int getNumero() {
		return numero;
	}

}

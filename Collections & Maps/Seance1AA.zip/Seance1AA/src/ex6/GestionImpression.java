package ex6;

public class GestionImpression {
	

	
	public void ajouterImpression(Impression impr){

	}
	
	public Impression selectionnerImpression(){

	}


}

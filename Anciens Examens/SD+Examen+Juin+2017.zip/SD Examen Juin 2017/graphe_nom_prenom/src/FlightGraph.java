import java.util.HashMap;
import java.util.Map;



public class FlightGraph {
	private int numberOfAirports;
	private Flight[][] flights;
	private Map<Airport,Integer> airportNumber;
	
	public FlightGraph(Airport... airports){
		numberOfAirports=airports.length;
		this.flights= new Flight[numberOfAirports][numberOfAirports];
		airportNumber= new HashMap<Airport,Integer>();
		for (int i=0;i<numberOfAirports;i++){
			airportNumber.put(airports[i], i);
		}
	}
	
	public void addFlight(Airport source,Airport destination, String code){
		if (airportNumber.get(source)==null||airportNumber.get(destination)==null)throw new IllegalArgumentException();
		Flight f= new Flight(source,destination, code);
		flights[airportNumber.get(source)][airportNumber.get(destination)]=f;
	}
	
	public void dfs(Airport source){
	// a completer
	}
}

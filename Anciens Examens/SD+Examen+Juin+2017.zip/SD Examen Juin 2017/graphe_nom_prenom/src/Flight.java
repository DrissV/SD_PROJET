
public class Flight {
	private final Airport source;
	private final Airport destination;
	private final String code;
	public Flight(Airport source, Airport destination, String code) {
		super();
		this.source = source;
		this.destination = destination;
		this.code=code;
	}
	public Airport getSource() {
		return source;
	}
	public Airport getDestination() {
		return destination;
	}
	public String getCode() {
		return code;
	}
	
	
}

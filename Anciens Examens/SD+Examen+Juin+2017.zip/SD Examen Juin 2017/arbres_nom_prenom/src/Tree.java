
public class Tree {
	private int value;
	private Tree[] children;

	public int getValue() {
		return value;
	}

	// *******************************************************
	// CONSTRUCTEURS
	// *******************************************************
	public Tree(int v, Tree[] chd) {
		value = v;
		children = chd;
	}

	public Tree(int v) {
		this(v, new Tree[0]);
	}
	
	
	public int height(){
		// a compl�ter
		return -1;
	}
	
	// cette m�thode sera toujours appel�e sur la racine d'un arbre
	public void printNodesWithAncestors() {
		// a compl�ter
	}
}

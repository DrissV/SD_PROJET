public class Tree {
	private int value;
	private Tree[] children;

	public int getValue() {
		return value;
	}

	// *******************************************************
	// CONSTRUCTEURS
	// *******************************************************
	public Tree(int v, Tree[] chd) {
		value = v;
		children = chd;
	}

	public Tree(int v) {
		this(v, new Tree[0]);
	}
	
	public boolean racinePlusGrande(){
		return false;
	}

	public void afficherNoeudsAvecSomme() {
	}

}

public class Test {
	public static void main(String[] args) {
		Airport la= new Airport("LA", "Los Angeles");
		Airport ord= new Airport ("ORD", "Chicago");
		Airport bos= new Airport("BOS", "Boston");
		Airport jfk= new Airport("JFK", "New-York");
		Airport mia= new Airport("MIA", "Miami");
		Airport dfw = new Airport("DFW","Dallas");
		Airport bru= new Airport("BRU","Bruxelles");
		Airport par= new Airport("PAR","Paris");
		FlightGraph f= new FlightGraph(la, ord, bos, jfk, mia, dfw,bru,par);
		f.addFlight(bos, jfk, "NW35");
		f.addFlight(jfk, mia, "AA90");
		f.addFlight(jfk, dfw, "AA13");
		f.addFlight(mia, dfw, "AA52");
		f.addFlight(mia, la, "AA41");
		f.addFlight(la, ord, "UA12");
		f.addFlight(ord, bos, "DL17");
		f.addFlight(ord, dfw, "UA87");
		f.addFlight(dfw, ord, "DL33");
		f.addFlight(bru, par, "BA145");

		f.bfs(ord);
		//System.out.println(f.connexe());
	}
}
